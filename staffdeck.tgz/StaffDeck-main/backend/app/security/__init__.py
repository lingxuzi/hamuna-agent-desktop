"""Security helpers."""

